package main;

public class SearchCommand extends Command{
	
	public SearchCommand(ParsedInput input, Memory memory) {
		super(input, memory);
	}

	@Override
	public Signal execute() {
		// TODO Auto-generated method stub
		return null;
	}

}
